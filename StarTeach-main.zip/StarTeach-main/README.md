# StarTeach
This project helps entrepreneur from start of their journey to the end. Helping them on their idea, get resources to advance in their journey and helping them with all the legal documentations 
